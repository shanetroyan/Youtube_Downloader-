import tkinter as tk
from pytube import YouTube

Dock = tk.Tk()

Dock.geometry('500x300')
Dock.resizable(0,0)

Dock.title("Youtube Downloader")
tk.Label(Dock, text="Youtube Video Downloader (Using Python and Tkinter)", font= "calibri 14 bold").pack()
link = tk.StringVar()
tk.Label(Dock, text="Enter URL of Youtube Video Here", font = "calibri 12 bold").place(x=160,y=60)
link_error= tk.Entry (Dock, width=70, textvariable = link).place (x=32,y=90)



def DownloadFunction():
    url = YouTube(str(link.get()))
    video = url.streams.first()
    video.download()
    tk.Label(Dock, text= "Successfully Downloaded", font = "calibri 12 bold").place(x=100, y=200)


tk.Button(Dock, text= "Download", font = "impact 12 bold", bg = "red", padx=2,command=DownloadFunction).place(x=180,y=150)
Dock.mainloop()